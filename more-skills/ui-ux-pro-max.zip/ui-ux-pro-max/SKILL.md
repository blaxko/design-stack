---
name: ui-ux-pro-max
description: UI UX Pro Max design intelligence (nextlevelbuilder/ui-ux-pro-max-skill): searchable database of UI styles, color palettes, font pairings, UX rules and industry-specific design systems, plus sub-skills for design systems, brand identity, banners, slides and Tailwind/shadcn styling. Use when choosing a visual style, palette, typography or design system for a product, generating a design system, styling UI with Tailwind or shadcn, designing banners, brand assets or slides, or when the user mentions ui-ux-pro-max.
---

# UI UX Pro Max

Design knowledge base with a local search script (Python 3, no dependencies). Main entry: `ui-ux-pro-max` (design-system generator and style/palette/font search). Others: `design`, `design-system`, `brand`, `banner-design`, `slides`, `ui-styling`.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/banner-design`), treat it as a request for that sub-skill.

`<SKILL_ROOT>` in commands means the absolute path of this bundle's folder (the folder containing this SKILL.md). Run scripts with `python3`.

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `banner-design` | Design banners for social media, ads, website heroes, creative assets, and print. Multiple art direction options with optional generated or supplied visuals. Actions:… | `skills/banner-design/INSTRUCTIONS.md` |
| `brand` | Brand voice, visual identity, messaging frameworks, asset management, brand consistency. Activate for branded content, tone of voice, marketing assets, brand… | `skills/brand/INSTRUCTIONS.md` |
| `design` | Comprehensive design skill: brand identity, design tokens, UI styling, logo generation (55 styles, Gemini, Atlas Cloud, or MuAPI AI), corporate identity program (50… | `skills/design/INSTRUCTIONS.md` |
| `design-system` | Token architecture, component specifications, and slide generation. Three-layer tokens (primitive→semantic→component), CSS variables, spacing/typography scales,… | `skills/design-system/INSTRUCTIONS.md` |
| `slides` | Create strategic HTML presentations with Chart.js, design tokens, responsive layouts, copywriting formulas, and contextual slide strategies. | `skills/slides/INSTRUCTIONS.md` |
| `ui-styling` | Create beautiful, accessible user interfaces with shadcn/ui components (built on Radix UI + Tailwind), Tailwind CSS utility-first styling, and canvas-based visual… | `skills/ui-styling/INSTRUCTIONS.md` |
| `ui-ux-pro-max` | UI/UX design intelligence for web, mobile, and desktop. This skill should be used when designing, building, reviewing, or fixing interfaces, including pages,… | `skills/ui-ux-pro-max/INSTRUCTIONS.md` |
