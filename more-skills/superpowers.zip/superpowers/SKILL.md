---
name: superpowers
description: Superpowers (obra/superpowers) software-development methodology: brainstorm before building, write a plan, execute it with subagents, test-driven development, systematic debugging, verification before claiming done, code review, git worktrees and finishing a branch. Use when starting any feature or project, planning or executing multi-step coding work, debugging a bug or failing test, before saying work is complete, when requesting or receiving code review, or when the user mentions superpowers, brainstorm, write a plan, TDD or systematic debugging.
---

# Superpowers

Jesse Vincent's methodology for coding agents (MIT). Default flow for real feature work: `brainstorming` → `writing-plans` → `executing-plans` or `subagent-driven-development` → `test-driven-development` throughout → `verification-before-completion` → `requesting-code-review` → `finishing-a-development-branch`. Start with `using-superpowers` the first time in a session.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/brainstorming`), treat it as a request for that sub-skill.

The original plugin injects `using-superpowers` automatically at session start; here, read it yourself before the first coding task of a session.

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `brainstorming` | You MUST use this before any creative work - creating features, building components, adding functionality, modifying behavior, or planning anything new, in software or… | `skills/brainstorming/INSTRUCTIONS.md` |
| `diagnosing-superpowers` | Use when a superpowers session went wrong and your human partner wants to know why — repeated work, ignored plans, stumbles, poor results, a skill that didn't fire, "it… | `skills/diagnosing-superpowers/INSTRUCTIONS.md` |
| `dispatching-parallel-agents` | Use when facing 2+ independent tasks that can be worked on without shared state or sequential dependencies | `skills/dispatching-parallel-agents/INSTRUCTIONS.md` |
| `executing-plans` | Use when executing an implementation plan in the current session as the implementer yourself — your human partner chose inline execution, or no subagent tool is available | `skills/executing-plans/INSTRUCTIONS.md` |
| `finishing-a-development-branch` | Use when implementation is complete, all tests pass, and you need to decide how to integrate the work | `skills/finishing-a-development-branch/INSTRUCTIONS.md` |
| `receiving-code-review` | Use when receiving code review feedback, before implementing suggestions, especially if feedback seems unclear or technically questionable - requires technical rigor… | `skills/receiving-code-review/INSTRUCTIONS.md` |
| `requesting-code-review` | Use when completing tasks, implementing major features, or before merging to verify work meets requirements | `skills/requesting-code-review/INSTRUCTIONS.md` |
| `subagent-driven-development` | Use when executing implementation plans with independent tasks in the current session | `skills/subagent-driven-development/INSTRUCTIONS.md` |
| `systematic-debugging` | Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes | `skills/systematic-debugging/INSTRUCTIONS.md` |
| `test-driven-development` | Use when implementing any feature or bugfix, before writing implementation code | `skills/test-driven-development/INSTRUCTIONS.md` |
| `using-git-worktrees` | Use when starting feature work that needs isolation from current workspace or before executing implementation plans - ensures an isolated workspace exists via native… | `skills/using-git-worktrees/INSTRUCTIONS.md` |
| `using-superpowers` | Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying questions | `skills/using-superpowers/INSTRUCTIONS.md` |
| `verification-before-completion` | Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before… | `skills/verification-before-completion/INSTRUCTIONS.md` |
| `writing-plans` | Use when you have a spec or requirements for a multi-step task, before touching code | `skills/writing-plans/INSTRUCTIONS.md` |
| `writing-skills` | Use when creating new skills, editing existing skills, or verifying skills work before deployment | `skills/writing-skills/INSTRUCTIONS.md` |
