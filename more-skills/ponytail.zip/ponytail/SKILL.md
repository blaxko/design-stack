---
name: ponytail
description: Ponytail, the lazy senior dev (DietrichGebert/ponytail): write the least code that works, delete instead of add, reuse what exists, and still test risky logic. Includes review, audit, tech-debt and gain-report modes. Use when the user asks for ponytail, minimal or simplest code, less code, to cut bloat, to review a diff for over-engineering, to audit a codebase for complexity or tech debt, or invokes /ponytail, /ponytail-review, /ponytail-audit, /ponytail-debt or /ponytail-gain.
---

# Ponytail

Puts a terse, lazy-in-the-good-way senior engineer in charge of the code: smallest correct change, no speculative abstraction, tests where the risk is.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/ponytail`), treat it as a request for that sub-skill.

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `ponytail` |  | `skills/ponytail/INSTRUCTIONS.md` |
| `ponytail-audit` |  | `skills/ponytail-audit/INSTRUCTIONS.md` |
| `ponytail-debt` |  | `skills/ponytail-debt/INSTRUCTIONS.md` |
| `ponytail-gain` |  | `skills/ponytail-gain/INSTRUCTIONS.md` |
| `ponytail-help` |  | `skills/ponytail-help/INSTRUCTIONS.md` |
| `ponytail-review` |  | `skills/ponytail-review/INSTRUCTIONS.md` |
