---
name: understand-anything
description: Understand Anything (Egonex-AI/Understand-Anything): analyze a codebase, docs or knowledge base into an interactive knowledge graph with plain-English summaries, a domain/business-flow view, guided onboarding tours, diff impact analysis, Q&A over the graph and a local dashboard. Use when the user wants to understand an unfamiliar codebase, onboard to a repo, see how files and features connect, explain a module, analyze the impact of a diff, map business domains, or invokes /understand, /understand-chat, /understand-explain, /understand-onboard, /understand-diff, /understand-domain or /understand-dashboard.
---

# Understand Anything

Multi-agent pipeline that builds `.understand-anything/knowledge-graph.json` for a project, then lets you chat with it, explain parts, onboard, review diffs and open a dashboard. Start with `understand` (builds the graph), then use the others.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/understand`), treat it as a request for that sub-skill.

**Setup (do this first, once per session):** this bundle holds only the instructions; the pipeline's scripts, agent prompts and packages live in the original repo. Fetch them into a writable scratch folder and point the instructions at it:
```
git clone --depth 1 https://github.com/Egonex-AI/Understand-Anything <scratch>/ua
export CLAUDE_PLUGIN_ROOT=<scratch>/ua/understand-anything-plugin
```
Needs Node.js 22+ and pnpm 10+ (`npm i -g pnpm` if missing). Then read the sub-skill's INSTRUCTIONS.md here, but treat `<SKILL_DIR>` in it as `$CLAUDE_PLUGIN_ROOT/skills/<that sub-skill>` (that's where its .mjs/.py helpers are). Agent prompts it refers to are in `$CLAUDE_PLUGIN_ROOT/agents/`; dispatch them as subagents, or do the step yourself if subagents aren't available.

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `understand` | Analyze a codebase to produce an interactive knowledge graph for understanding architecture, components, and relationships | `skills/understand/INSTRUCTIONS.md` |
| `understand-chat` | Use when you need to ask questions about a codebase or understand code using a knowledge graph | `skills/understand-chat/INSTRUCTIONS.md` |
| `understand-dashboard` | Launch the interactive web dashboard to visualize a codebase's knowledge graph | `skills/understand-dashboard/INSTRUCTIONS.md` |
| `understand-diff` | Use when you need to analyze git diffs or pull requests to understand what changed, affected components, and risks | `skills/understand-diff/INSTRUCTIONS.md` |
| `understand-domain` | Extract business domain knowledge from a codebase and generate an interactive domain flow graph. Works standalone (lightweight scan) or derives from an existing… | `skills/understand-domain/INSTRUCTIONS.md` |
| `understand-explain` | Use when you need a deep-dive explanation of a specific file, function, or module in the codebase | `skills/understand-explain/INSTRUCTIONS.md` |
| `understand-figma` | Analyze a Figma file via the Figma REST API and generate an interactive design knowledge graph (pages, screens, components, component sets, instances, design tokens)… | `skills/understand-figma/INSTRUCTIONS.md` |
| `understand-knowledge` | Analyze a Karpathy-pattern LLM wiki knowledge base and generate an interactive knowledge graph with entity extraction, implicit relationships, and topic clustering. | `skills/understand-knowledge/INSTRUCTIONS.md` |
| `understand-onboard` | Use when you need to generate an onboarding guide for new team members joining a project | `skills/understand-onboard/INSTRUCTIONS.md` |
