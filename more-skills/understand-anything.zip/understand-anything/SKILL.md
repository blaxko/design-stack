---
name: understand-anything
description: Understand Anything (Egonex-AI/Understand-Anything): analyze a codebase, docs or knowledge base into an interactive knowledge graph with plain-English summaries, a domain/business-flow view, guided onboarding tours, diff impact analysis, Q&A over the graph and a local dashboard. Use when the user wants to understand an unfamiliar codebase, onboard to a repo, see how files and features connect, explain a module, analyze the impact of a diff, map business domains, or invokes /understand, /understand-chat, /understand-explain, /understand-onboard, /understand-diff, /understand-domain or /understand-dashboard.
---

# Understand Anything

Multi-agent pipeline that builds `.understand-anything/knowledge-graph.json` for a project, then lets you chat with it, explain parts, onboard, review diffs and open a dashboard. Start with `understand` (builds the graph), then use the others.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `plugin/skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/understand`), treat it as a request for that sub-skill.

**Setup (needed by `understand` and the dashboard):** the pipeline needs its plugin workspace, bundled here in `plugin/`, plus Node.js 22+ and pnpm 10+. Skill folders may be read-only, so first copy it somewhere writable: `cp -r <this bundle>/plugin <scratch>/ua-plugin`, then `export CLAUDE_PLUGIN_ROOT=<scratch>/ua-plugin` before following the sub-skill (its steps run `pnpm install` and build there). `<SKILL_DIR>` in a sub-skill means `$CLAUDE_PLUGIN_ROOT/skills/<that sub-skill>`. Agent prompts it refers to are in `$CLAUDE_PLUGIN_ROOT/agents/`; when it asks to dispatch them, use subagents (or do the step yourself if subagents aren't available).

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `understand` | Analyze a codebase to produce an interactive knowledge graph for understanding architecture, components, and relationships | `plugin/skills/understand/INSTRUCTIONS.md` |
| `understand-chat` | Use when you need to ask questions about a codebase or understand code using a knowledge graph | `plugin/skills/understand-chat/INSTRUCTIONS.md` |
| `understand-dashboard` | Launch the interactive web dashboard to visualize a codebase's knowledge graph | `plugin/skills/understand-dashboard/INSTRUCTIONS.md` |
| `understand-diff` | Use when you need to analyze git diffs or pull requests to understand what changed, affected components, and risks | `plugin/skills/understand-diff/INSTRUCTIONS.md` |
| `understand-domain` | Extract business domain knowledge from a codebase and generate an interactive domain flow graph. Works standalone (lightweight scan) or derives from an existing… | `plugin/skills/understand-domain/INSTRUCTIONS.md` |
| `understand-explain` | Use when you need a deep-dive explanation of a specific file, function, or module in the codebase | `plugin/skills/understand-explain/INSTRUCTIONS.md` |
| `understand-figma` | Analyze a Figma file via the Figma REST API and generate an interactive design knowledge graph (pages, screens, components, component sets, instances, design tokens)… | `plugin/skills/understand-figma/INSTRUCTIONS.md` |
| `understand-knowledge` | Analyze a Karpathy-pattern LLM wiki knowledge base and generate an interactive knowledge graph with entity extraction, implicit relationships, and topic clustering. | `plugin/skills/understand-knowledge/INSTRUCTIONS.md` |
| `understand-onboard` | Use when you need to generate an onboarding guide for new team members joining a project | `plugin/skills/understand-onboard/INSTRUCTIONS.md` |
