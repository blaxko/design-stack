---
name: 60fps-motion
description: Official 60fps.design motion skills (MIT) for app interaction design - find where an app should animate, design loading, success, empty and error feedback states, build a consistent motion system (timings, springs, haptics), turn a reference interaction into a developer handoff spec, and recreate shipped interactions. Built for iOS and SwiftUI with the 60fps clip library; also usable for web and Android by translating values. Use when asked to add or audit animations, micro-interactions, transitions, feedback states, motion tokens or a motion spec for an app.
---

# 60fps motion skills

Five official skills from 60fps.design (github.com/60fps-Design/plugin, MIT). Read the matching sub-skill's INSTRUCTIONS.md in full and follow it.

| Sub-skill | Use when | File |
|---|---|---|
| `find-animation-opportunities` | Where should this app animate, what to leave still, what motion is broken or overdone | `skills/find-animation-opportunities/INSTRUCTIONS.md` |
| `feedback-states` | Loading, refreshing, success, empty, error and retry states for a feature or screen | `skills/feedback-states/INSTRUCTIONS.md` |
| `motion-system` | One consistent motion language: named timings, springs, haptics in one file | `skills/motion-system/INSTRUCTIONS.md` |
| `motion-spec` | Turn an interaction into a handoff spec: trigger, beats, springs, interruptions, Reduce Motion | `skills/motion-spec/INSTRUCTIONS.md` |
| `motion-reference` | Build an interaction by copying one that shipped, with compile-checked SwiftUI | `skills/motion-reference/INSTRUCTIONS.md` |

## The 60fps server (paid, optional)
The sub-skills call tools such as `60fps_search_shots`, `get_motion_breakdown` and `get_motion_code` from the hosted 60fps MCP server (`https://mcp.60fps.design/mcp`, OAuth sign-in, needs a 60fps MCP licence, about $29/month). If those tools aren't available in this session:
- Still follow the sub-skill's method (audit, states, timings, spec structure); it stands on its own.
- Replace "search shots" with your own knowledge of well-known shipped interactions, and say so; you can link the user to browse `https://60fps.design/shots/filter/<tag>` (e.g. `spring-physics`, `success-state`, `loading`) to pick a reference.
- Mark anything you couldn't verify against a real clip as "not verified".
To connect it (if the user has a licence): Claude app → Settings → Connectors → Add custom connector → `https://mcp.60fps.design/mcp`; Claude Code CLI: `claude mcp add --transport http 60fps https://mcp.60fps.design/mcp`.

## Web and Android projects
The sub-skills target SwiftUI. For web, translate: SwiftUI `spring(response:dampingFraction:)` → Motion (Framer Motion) `type:"spring"` with similar stiffness/damping, or CSS `cubic-bezier`; haptics → skip or use subtle visual feedback; `withAnimation` → CSS transitions/Motion. For Android, use Jetpack Compose `spring()`/`tween()` and `HapticFeedback`. For web section-level motion also see the `web-sections` skill.
