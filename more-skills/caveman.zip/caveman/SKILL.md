---
name: caveman
description: Caveman (JuliusBrussee/caveman): make the agent talk and read less to save tokens while keeping code exact, with terse reply modes (caveman, ultracave, megacave), terse commits and reviews, prompt and file compression, plus lean workflows such as investigate-first, surgical-patch, safe-refactor, verify-and-stop, lean-build and migration. Use when the user asks for caveman mode, shorter or terser answers, fewer tokens, to compress a prompt or CLAUDE.md, a caveman commit or review, or invokes any /caveman, /ultracave, /megacave or /cavecrew command.
---

# Caveman

Terse-output modes and lean coding workflows. Reply modes stay on until the user says stop or normal mode. Even in caveman mode, use full sentences for security warnings, irreversible actions and step-by-step instructions.

## How to use this bundle
This one skill packs several skills from the original repo. Pick the sub-skill(s) whose "use when" matches the task, **read its INSTRUCTIONS.md in full**, and follow it exactly as if it were a standalone skill. Paths inside a sub-skill (scripts/, references/, data/) are relative to that sub-skill's folder in this bundle. When a sub-skill tells you to use another skill by name (e.g. `prefix:other-skill` or `/other-skill`), open `skills/other-skill/INSTRUCTIONS.md` here. When the user types a slash command named after a sub-skill (e.g. `/cavecrew`), treat it as a request for that sub-skill.

The original plugin can auto-enable caveman at session start via hooks; as an account skill it turns on only when asked.

## Sub-skills
| Sub-skill | Use when | File |
|---|---|---|
| `cavecrew` |  | `skills/cavecrew/INSTRUCTIONS.md` |
| `caveman` |  | `skills/caveman/INSTRUCTIONS.md` |
| `caveman-commit` |  | `skills/caveman-commit/INSTRUCTIONS.md` |
| `caveman-compress` |  | `skills/caveman-compress/INSTRUCTIONS.md` |
| `caveman-discover` |  | `skills/caveman-discover/INSTRUCTIONS.md` |
| `caveman-evidence-review` |  | `skills/caveman-evidence-review/INSTRUCTIONS.md` |
| `caveman-explore` | Read-only repository explorer for cold-start orientation, broad cross-file localization, or when a direct search failed. Skip it when the exact file or symbol is… | `skills/caveman-explore/INSTRUCTIONS.md` |
| `caveman-help` |  | `skills/caveman-help/INSTRUCTIONS.md` |
| `caveman-learn` | Act on a Caveman learn report - review the ranked token sinks, apply cost-lowering fixes with per-edit consent, and report what those fixes returned. Use when asked to… | `skills/caveman-learn/INSTRUCTIONS.md` |
| `caveman-manage` |  | `skills/caveman-manage/INSTRUCTIONS.md` |
| `caveman-optimize` |  | `skills/caveman-optimize/INSTRUCTIONS.md` |
| `caveman-review` |  | `skills/caveman-review/INSTRUCTIONS.md` |
| `caveman-setup` |  | `skills/caveman-setup/INSTRUCTIONS.md` |
| `caveman-stats` |  | `skills/caveman-stats/INSTRUCTIONS.md` |
| `investigate-first` | Diagnose ambiguous failures before editing. Use for unknown causes, intermittent behavior, performance regressions, or investigations needing evidence-ranked hypotheses. | `skills/investigate-first/INSTRUCTIONS.md` |
| `lean-build` | Build feature work with high overbuilding risk. Use for new behavior, product slices, or integrations where repository reuse, strict scope, and an explicit stop… | `skills/lean-build/INSTRUCTIONS.md` |
| `megacave` |  | `skills/megacave/INSTRUCTIONS.md` |
| `migration` | Implement reversible compatibility-safe transitions. Use for schema, data, API, protocol, configuration, or dependency migrations requiring rollback and preservation… | `skills/migration/INSTRUCTIONS.md` |
| `safe-refactor` | Restructure code while preserving behavior. Use for extraction, consolidation, ownership moves, or cleanup where verification must bracket structural edits. | `skills/safe-refactor/INSTRUCTIONS.md` |
| `surgical-patch` | Fix bugs and small behavior changes at the narrowest responsible layer. Use when regression proof, preserved surrounding behavior, and task-relevant tests matter. | `skills/surgical-patch/INSTRUCTIONS.md` |
| `ultracave` |  | `skills/ultracave/INSTRUCTIONS.md` |
| `verify-and-stop` | Prove existing work meets acceptance conditions without expanding scope. Use for validation-only tasks, completion checks, focused gate runs, and last-mile proof. | `skills/verify-and-stop/INSTRUCTIONS.md` |
